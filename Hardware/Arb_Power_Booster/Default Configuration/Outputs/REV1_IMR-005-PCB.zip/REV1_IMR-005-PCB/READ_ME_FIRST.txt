COMPANY AND BOARD INFORMATION
Address:
  IMR Engineering
  3621 Gin Way
  Snellville, GA 30039
Board:
  PN: 	IMR-005-PCB
  REV:	1

FOR ASSISTANCE:
ENGINEER: 	Hab Collector
EMAIL:		Hab.Collector@imrengineering.com
PHONE:		678-687-0270

FOR BUILD SPECIFICS SEE: 
See PCB Fabrication Layer (PO to override)

LAYER AND STACK ORDER:
ArbPwrBoost.GTO	Top Silk
ArbPwrBoost.GTS	Top SolderMask
ArbPwrBoost.GTP	Top PasteMask
ArbPwrBoost.GTL	Top 
ArbPwrBoost.G1	Inner Layer 1 
ArbPwrBoost.G2	Inner Layer 2 
ArbPwrBoost.GBL	Bottom
ArbPwrBoost.GBS	Bottom SolderMask
ArbPwrBoost.GBP	Bottom PasteMask
ArbPwrBoost.GBO	Bottom Silk
MORE:
ArbPwrBoost.TXT	Drill
ArbPwrBoost.APR	Aperture

